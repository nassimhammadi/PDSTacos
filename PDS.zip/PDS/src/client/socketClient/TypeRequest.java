package client.socketClient;

public enum TypeRequest {
	 UPDATE,
	 INSERT,
	 DELETE,
	 SELECT,
	 LOGIN	 
	
}
