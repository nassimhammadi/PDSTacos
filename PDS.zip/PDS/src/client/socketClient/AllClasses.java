package client.socketClient;

public enum AllClasses {
	VEHICULE,
	EMPLOYEE
}
