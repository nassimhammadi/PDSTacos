package client.socketClient;

public enum Parameter {
	ID,
	IMMAT,
	NAME,
	PWD, 
	YEAR, 
	PRESENCE, 
	VEHICULE
}
